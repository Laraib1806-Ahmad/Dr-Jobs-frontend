"use client";

import React, { useState } from "react";
import { FiCreditCard, FiCheck, FiMapPin, FiMail } from "react-icons/fi";

export default function BillingInfoTab() {
  const [isSaved, setIsSaved] = useState(false);

  return (
    <div className="bg-white rounded-2xl border border-gray-100/90 shadow-[0_1px_3px_rgba(0,0,0,0.03)] p-6 space-y-6">
      <div className="flex items-center justify-between border-b border-gray-100 pb-4">
        <div>
          <h2 className="text-base font-bold text-gray-900 tracking-tight">
            Billing Information & Payment Method
          </h2>
          <p className="text-xs text-gray-400 font-normal mt-0.5">
            Manage your organization payment methods and invoice details.
          </p>
        </div>
        {isSaved && (
          <span className="text-xs text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full font-medium flex items-center gap-1">
            <FiCheck /> Details updated
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Payment Methods */}
        <div className="space-y-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase tracking-wider">
            Primary Payment Method
          </h3>

          <div className="border border-blue-200 bg-blue-50/40 rounded-xl p-4 flex items-start justify-between">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-600 text-white flex items-center justify-center text-lg shrink-0">
                <FiCreditCard />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-gray-900">
                    Visa ending in 4242
                  </span>
                  <span className="text-[10px] bg-blue-600 text-white px-2 py-0.5 rounded-full font-semibold">
                    DEFAULT
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">Expiry 08/2028</p>
                <p className="text-xs text-gray-400 mt-0.5">dream com • UAE</p>
              </div>
            </div>
            <button
              type="button"
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              Edit
            </button>
          </div>
        </div>

        {/* Billing Address & Details */}
        <div className="space-y-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase tracking-wider">
            Billing Address & Company
          </h3>

          <div className="border border-gray-200/80 rounded-xl p-4 space-y-2 text-xs text-gray-600">
            <div className="flex items-center gap-2 font-bold text-gray-900">
              <span className="text-sm">🇦🇪</span>
              <span>dream com LLC</span>
            </div>
            <div className="flex items-start gap-2 text-gray-600">
              <FiMapPin className="text-gray-400 shrink-0 mt-0.5" />
              <span>Dubai Internet City, Building 3, Dubai, United Arab Emirates</span>
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <FiMail className="text-gray-400 shrink-0" />
              <span>billing@dreamcom.ae</span>
            </div>
            <div className="pt-2 border-t border-gray-100 flex items-center justify-between text-gray-500">
              <span>Tax / TRN: 100293847500003</span>
              <button
                type="button"
                onClick={() => setIsSaved(true)}
                className="text-blue-600 font-semibold hover:underline cursor-pointer"
              >
                Update
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
