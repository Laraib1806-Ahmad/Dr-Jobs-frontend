"use client";

import React from "react";
import {
  FiArrowLeft,
  FiUsers,
  FiClock,
  FiShield,
  FiCreditCard,
  FiChevronRight,
} from "react-icons/fi";
import { IoDiamondOutline } from "react-icons/io5";
import { LuSparkles } from "react-icons/lu";
import { FaCrown } from "react-icons/fa6";

interface SidebarProps {
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
  activeItem?: string;
  setActiveItem?: (item: string) => void;
}

export default function Sidebar({
  isCollapsed = false,
  onToggleCollapse,
  activeItem = "Billing",
  setActiveItem,
}: SidebarProps) {
  const navItems = [
    { name: "Members", icon: FiUsers },
    { name: "Subscriptions", icon: IoDiamondOutline },
    { name: "Billing", icon: FiCreditCard },
    { name: "History", icon: FiClock },
    { name: "AI Settings", icon: LuSparkles },
    { name: "Security", icon: FiShield },
  ];

  return (
    <aside
      className={`bg-white border-r border-gray-100 flex flex-col justify-between transition-all duration-300 select-none z-20 ${
        isCollapsed ? "w-30" : "w-64"
      } min-h-screen p-4`}
    >
      {/* Top Section */}
      <div className="flex flex-col gap-5">
        {/* Logo & Collapse toggle */}
        <div className="flex items-center justify-between px-1 pt-1">
          <div className="flex items-center gap-1.5 cursor-pointer">
            <span className="text-xl font-black tracking-tight text-gray-950 font-sans">
              Dr.Job
            </span>
          </div>

          <button
            type="button"
            onClick={onToggleCollapse}
            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="text-gray-400 hover:text-gray-700 hover:bg-gray-100 p-1.5 rounded-lg transition-colors cursor-pointer text-xs flex items-center justify-center"
          >
            {/* Custom collapse icon matching `<|` in screenshot */}
            <svg
              className={`w-3.5 h-3.5 transition-transform duration-200 ${
                isCollapsed ? "rotate-180" : ""
              }`}
              viewBox="0 0 16 16"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polyline points="10 13 5 8 10 3" />
              <line x1="14" y1="3" x2="14" y2="13" />
            </svg>
          </button>
        </div>

        {/* Back to Main Menu Button */}
        <div>
          <button
            type="button"
            className="w-full bg-[#f4f5f8] hover:bg-gray-200/70 text-gray-700 text-xs font-semibold py-2 px-3 rounded-xl flex items-center gap-2 transition-colors cursor-pointer"
            title="Back to Main Menu"
          >
            <FiArrowLeft className="text-sm shrink-0" />
            {!isCollapsed && (
              <span className="truncate">Back to Main Menu</span>
            )}
          </button>
        </div>

        <nav className="flex flex-col gap-1 mt-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeItem === item.name;

            return (
              <button
                key={item.name}
                type="button"
                onClick={() => setActiveItem?.(item.name)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all duration-150 cursor-pointer ${
                  isActive
                    ? "bg-[#edf3ff] text-[#2563eb] font-semibold"
                    : "text-gray-600 hover:text-gray-900 hover:bg-gray-50"
                }`}
                title={item.name}
              >
                <Icon
                  className={`text-base shrink-0 ${
                    isActive ? "text-[#2563eb]" : "text-gray-500"
                  }`}
                />
                {!isCollapsed && <span className="truncate">{item.name}</span>}
              </button>
            );
          })}
        </nav>
      </div>

      <div className="flex flex-col gap-3 pt-4">
        <div className="border border-gray-200/70 hover:border-gray-300/80 bg-white hover:bg-gray-50/60 p-2.5 rounded-xl flex items-center justify-between cursor-pointer transition-colors">
          <div className="flex items-center gap-2.5 overflow-hidden">
            {/* UAE Flag Icon */}
            <div className="w-5 h-3.5 shrink-0 rounded-xs overflow-hidden flex shadow-xs border border-gray-200/50">
              {/* UAE Flag: vertical red bar on left, 3 horizontal bars (green, white, black) on right */}
              <div className="w-1.5 h-full bg-[#e31b23] shrink-0" />
              <div className="flex flex-col flex-1 h-full">
                <div className="h-1/3 bg-[#00732f]" />
                <div className="h-1/3 bg-white" />
                <div className="h-1/3 bg-black" />
              </div>
            </div>

            {!isCollapsed && (
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-bold text-gray-900 truncate leading-tight">
                  dream com
                </span>
                <span className="text-[10px] text-gray-400 truncate leading-tight mt-0.5">
                  1 Creator
                </span>
              </div>
            )}
          </div>

          {!isCollapsed && (
            <FiChevronRight className="text-gray-400 text-xs shrink-0 ml-1" />
          )}
        </div>
      </div>
    </aside>
  );
}
